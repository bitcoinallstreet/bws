Bitcoin W Spectrum Specifications

Coin Generation: Pure Proof of Stake

100,00,000 Coins 

RPC Port: 46646

Port: 46647

Time to Maturity: 60 Confirmations

Proof of Stake Reward: Random

Minimum Coin Stake Age: 2 hours

